package main

import (
  "fmt"
  "strconv"
)

func main() {

  input := "flag{********************************}"
  fmt.Println(transform(input[5:37]))
  // a72147bfc9985a7566ab007e1d5c724b
}
func convert(m int64) int64{
  m = m ^ m >> 13
  m = m ^ m << 9 & 2029229568
  m = m ^ m << 17 & 2245263360
  m = m ^ m >> 19
  return m
}

func transform(message string) string{
  newMessage := ""
  for i := 0; i < len(message)/8; i++ {
    block := message[i * 8 : i * 8 + 8]
    t, _ := strconv.ParseInt(block, 16, 64)
    r := convert(t)
    formatInt := fmt.Sprintf("%02s", strconv.FormatInt(r, 16))
    newMessage += formatInt
  }
  return newMessage
}
