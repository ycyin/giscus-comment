package com.yyc;

import org.jboss.resteasy.annotations.jaxrs.PathParam;
import org.jboss.resteasy.annotations.jaxrs.QueryParam;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;

@Path("/library")
public class Library {

   @GET
   @Path("/books")
   public String getBooks() {
      return "books";
   }

   @GET
   @Path("/book/{isbn}")
   public String getBook(@PathParam("isbn") String id) {
      // search my database and get a string representation and return it
      return "book"+id;
   }

   @PUT
   @Path("/book/{isbn}")
   public void addBook(@PathParam("isbn") String id, @QueryParam("name") String name) {
      System.out.println(id+"/"+name);
   }

   @DELETE
   @Path("/book/{id}")
   public void removeBook(@PathParam("id") String id ){
      System.out.println(id);
   }
   
}