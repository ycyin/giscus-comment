-- 添加表字段
alter table t_author add birthday_date date;