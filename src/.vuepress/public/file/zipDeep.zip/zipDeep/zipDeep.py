#-*-coding:utf-8-*-
import zipfile
import os
import re
from threading import Thread

#password='1234'
def pojie_zip(path,password,zip):
 if path[-4:]=='.zip':
  #path = dir+ '\\' +file
  #print path
  #print(path)
  try:
   #若解压成功，则返回True,和密码
   zip.extractall(path='C:\\Users\\travelskyy\\Desktop\\zipDeep',members=zip.namelist() , pwd=password.encode('ascii'))
   print(' ----success!,The password is %s' % password)
   zip.close()
   return True
  except Exception as e:
   #print(e)   
   pass #如果发生异常，不报错
 #print('error')
  
  
def get_pass():
 #压缩文件的路径
 path = r'C:\\Users\\travelskyy\\Desktop\\zipDeep\\1024.zip'
 print('正在尝试解压 %s'% path)
 for i in range(2048): 
   zip = zipfile.ZipFile(path, "r",zipfile.zlib.DEFLATED)
   #print(zip.namelist())
   #print(zip.namelist()[0][0:4])
   #密码字典的路径
   passPath='C:\\Users\\travelskyy\\Desktop\\zipDeep\\passwd.txt'
   passFile=open(passPath,'r')
   for line in passFile.readlines():
    password=line.strip('\n')
    #print('Try the password %s' % password)
    if pojie_zip(path,password,zip):
     pattern = re.compile(r'[0-4]{4}')
     #print(pattern.findall(path))
     path = re.sub(pattern, zip.namelist()[0][0:4], path)
     print('正在尝试解压 %s'% path)
     break
 passFile.close()
if __name__=='__main__':
 get_pass()
