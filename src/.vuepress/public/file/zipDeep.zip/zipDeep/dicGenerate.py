import itertools
dic='0124'
bs=[b+d+c+g for b in dic for d in dic for c in dic for g in dic]
with open("zidian.txt","w") as f:
  for line in bs:
    f.write(line+'\n')

def get_pwd():
    """获取四位数字的密码字典并保存在文件中去"""
    words = "0124"
    for x in itertools.permutations(words, 4):
        with open("passwd.txt", mode="a") as f:
            f.write("".join(x))
            f.write("\n")

get_pwd()            
