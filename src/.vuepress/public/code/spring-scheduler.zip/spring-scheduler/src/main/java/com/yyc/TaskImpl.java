package com.yyc;

import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import java.util.Date;

/**
 * @author ycyin
 * @Classname TaskImpl
 * @Description
 * @Date 2020/10/28/0028 09:40
 */
@Component
public class TaskImpl implements ITask{

    /**
     * 定时任务1
     */
    @Override
    @Async
    @Scheduled(cron = "0/5 * * * * ? ")
    public void taskMethod1() {
        System.out.println("TASK1-"+new Date()+"--"+Thread.currentThread());
    }

    /**
     * 定时任务2
     * @throws InterruptedException
     */
    @Override
    @Scheduled(cron = "0/5 * * * * ? ")
    public void taskMethod2() throws InterruptedException {
        Thread.sleep(10*1000);
        System.out.println("TASK2-"+new Date()+"--"+Thread.currentThread());
    }
}
