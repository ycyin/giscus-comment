package com.yyc;

/**
 * @author ycyin
 * @Classname com.yyc.ITask
 * @Description
 * @Date 2020/10/28/0028 09:39
 */
public interface ITask {

     void taskMethod1() throws InterruptedException;
     void taskMethod2() throws InterruptedException;
}
