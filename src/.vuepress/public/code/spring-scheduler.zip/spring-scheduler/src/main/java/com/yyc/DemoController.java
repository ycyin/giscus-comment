package com.yyc;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("demo")
public class DemoController {

    @RequestMapping("/test")
    @ResponseBody
    public Object hello(){
        System.out.println("hhhhhhhhhhhhhhhhhhhhhh");
        Map<String, Object> map=new HashMap<>();
        map.put("hello","world");
        return map;
    }
}
