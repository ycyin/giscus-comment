-- 创建t_author1表
CREATE TABLE IF NOT EXISTS `t_author1`(
   `id` INT UNSIGNED AUTO_INCREMENT,
   `real_name` VARCHAR(100) NOT NULL,
   `nick_name` VARCHAR(40) NOT NULL,
   PRIMARY KEY ( `id` )
)ENGINE=InnoDB DEFAULT CHARSET=utf8;