-- 添加表字段
alter table t_author1 add birthday_date date;
