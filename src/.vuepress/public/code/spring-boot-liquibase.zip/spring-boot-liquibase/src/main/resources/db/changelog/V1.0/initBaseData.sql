-- 添加数据
insert into t_author1(real_name,nick_name) values('张三','三儿');
insert into t_author1(real_name,nick_name) values('李四','四儿');
insert into t_author1(real_name,nick_name) values('王二麻子','麻子儿');
insert into t_author1(real_name,nick_name,birthday_date) values('张五','小五','2020-11-23');