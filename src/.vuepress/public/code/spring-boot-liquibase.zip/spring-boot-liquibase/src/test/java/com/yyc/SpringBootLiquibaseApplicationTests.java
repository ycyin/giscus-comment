package com.yyc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLiquibaseApplicationTests {

    @Test
    void contextLoads() {
    }

}
